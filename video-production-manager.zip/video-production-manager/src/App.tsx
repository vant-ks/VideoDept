import React from 'react';
import { Layout } from '@/components/Layout';
import { Dashboard } from '@/pages/Dashboard';
import { Sources } from '@/pages/Sources';
import { Sends } from '@/pages/Sends';
import { IPManagement } from '@/pages/IPManagement';
import { Checklist } from '@/pages/Checklist';
import { ScalingCalculator } from '@/pages/Calculator';
import { Screens, Switchers, Cabling, Settings } from '@/pages/OtherPages';
import { useProductionStore } from '@/hooks/useStore';

const App: React.FC = () => {
  const { activeTab } = useProductionStore();

  const renderPage = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'sources':
        return <Sources />;
      case 'sends':
        return <Sends />;
      case 'screens':
        return <Screens />;
      case 'switchers':
        return <Switchers />;
      case 'network':
        return <IPManagement />;
      case 'checklist':
        return <Checklist />;
      case 'cabling':
        return <Cabling />;
      case 'calculator':
        return <ScalingCalculator />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout>
      {renderPage()}
    </Layout>
  );
};

export default App;
