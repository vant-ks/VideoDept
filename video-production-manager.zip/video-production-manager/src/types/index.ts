// Core Production Types

export interface Production {
  id: string;
  client: string;
  showName: string;
  venue: string;
  room: string;
  loadIn: string;
  loadOut: string;
  showInfoUrl?: string;
}

export interface Source {
  id: string;
  type: SourceType;
  name: string;
  hRes?: number;
  vRes?: number;
  rate: number;
  standard?: string;
  note?: string;
  secondaryDevice?: string;
  output: ConnectorType;
}

export type SourceType = 
  | 'LAPTOP' 
  | 'CAM' 
  | 'SERVER' 
  | 'PLAYBACK' 
  | 'GRAPHICS' 
  | 'PTZ'
  | 'ROBO'
  | 'OTHER';

export interface Send {
  id: string;
  type: SendType;
  name: string;
  hRes?: number;
  vRes?: number;
  rate: number;
  standard?: string;
  note?: string;
  secondaryDevice?: string;
  output: ConnectorType;
}

export type SendType = 
  | 'VIDEO SWITCH' 
  | 'ROUTER' 
  | 'LED PROCESSOR' 
  | 'PROJECTOR'
  | 'MONITOR'
  | 'RECORD'
  | 'STREAM'
  | 'OTHER';

export type ConnectorType = 'HDMI' | 'SDI' | 'DP' | 'FIBER' | 'NDI' | 'USB-C';

// Equipment Types

export interface Projector {
  id: string;
  screenId: string;
  makeModel: string;
  mode: ResolutionMode;
  totalStacks: number;
  projectorsPerStack: number;
  stackLayout: StackLayout;
  stackPosition: StackPosition;
  displayOption: DisplayOption;
  nativeResolution?: Resolution;
  workingResolution: Resolution;
  dimensions?: ProjectorDimensions;
}

export type ResolutionMode = 'FHD' | 'UHD' | '4K' | 'WUXGA' | 'WQXGA' | 'Custom';

export type StackLayout = 
  | 'Side by Side, Flown' 
  | 'Side by Side, Ground'
  | 'Vertical, Flown'
  | 'Vertical, Ground'
  | 'Side by Side, Scaff'
  | 'Vertical, Scaff';

export type StackPosition = 
  | 'Front, Landscape' 
  | 'Front, Portrait'
  | 'Rear, Landscape'
  | 'Rear, Portrait';

export type DisplayOption = 'Single' | 'Blended' | 'Converged' | 'Mapped';

export interface Resolution {
  width: number;
  height: number;
}

export interface ProjectorDimensions {
  height: { imperial: string; metric: string };
  width: { imperial: string; metric: string };
  depth: { imperial: string; metric: string };
}

export interface LEDScreen {
  id: string;
  name: string;
  tileModel: string;
  processorModel: string;
  fullModules: { width: number; height: number };
  halfModules: { width: number; height: number };
  totalModules: { full: number; half: number };
  pixels: Resolution;
  aspectRatio: number;
  totalPixels: number;
  maxTilesPerPort: number;
  processorPortCount: number;
  processorCount: number;
  dimensionsFt: { width: string; height: string };
  dimensionsM: { width: string; height: string };
  hangingMax: number;
  stackingMax: number;
  powerMode: string;
}

export interface ProjectionScreen {
  id: string;
  name: string;
  horizontal: { ft: number; inches: number; meters: number };
  vertical: { ft: number; inches: number; meters: number };
  ratio: number;
  sqFt: number;
  sqM: number;
  projectorResolution: Resolution;
  totalPixels: number;
  blendWidth: { percent: number; pixels: number };
  blendCount: number;
  gainFactor: number;
  totalLumens: number;
  lumensPerPj: number;
  lumenUsage: { total: number; percentage: number };
  nits: number;
  pixelsPerSqFt: number;
  pixelsPerIn: number;
  contrastRatio: number;
  imageWidth: { ft: number; inches: number; meters: number };
  throwDistance: { ft: number; inches: number; meters: number };
}

// Network & Routing

export interface IPAddress {
  ip: string;
  device: string;
  category: IPCategory;
  notes?: string;
}

export type IPCategory = 
  | 'VIDEO' 
  | 'CAMS' 
  | 'FOH' 
  | 'HOUSE' 
  | 'RIGGING' 
  | 'LED'
  | 'NETWORK'
  | 'OTHER';

export interface Router {
  id: string;
  name: string;
  inputs: RouterIO[];
  outputs: RouterIO[];
}

export interface RouterIO {
  id: string;
  connector: ConnectorType;
  feed: string;
  notes?: string;
}

export interface VideoSwitcher {
  id: string;
  name: string;
  type: SwitcherType;
  ip?: string;
  inputs: SwitcherIO[];
  outputs: SwitcherIO[];
  layers?: SwitcherLayer[];
}

export type SwitcherType = 'E2' | 'Q8' | 'X80' | 'CARBONITE' | 'ATEM';

export interface SwitcherIO {
  id: string;
  connector: ConnectorType;
  feed: string;
  notes?: string;
}

export interface SwitcherLayer {
  id: string;
  name: string;
}

// Server & Media

export interface ServerAllocation {
  serverId: string;
  outputs: ServerOutput[];
}

export interface ServerOutput {
  id: number;
  processor?: string;
  resolution?: string;
  layers: ServerLayer[];
}

export interface ServerLayer {
  id: string;
  name: string;
}

// Checklists

export interface ChecklistItem {
  id: string;
  category: ChecklistCategory;
  item: string;
  dueDate?: string;
  completionDate?: string;
  completed: boolean;
  answer?: string;
  reference?: string;
  daysBeforeShow?: number;
}

export type ChecklistCategory = 
  | 'PRE_PRODUCTION'
  | 'SCREENS'
  | 'SWITCH'
  | 'IMAG'
  | 'MEDIA_SERVERS'
  | 'SOURCES'
  | 'DESTINATIONS'
  | 'DISPLAYS'
  | 'OUTSIDE_VENDORS'
  | 'DOCUMENTATION'
  | 'NOTES';

// Cable & Snake Management

export interface CableSnake {
  id: string;
  name: string;
  type: SnakeType;
  connections: SnakeConnection[];
}

export type SnakeType = 
  | 'ENG' 
  | 'VIDEO' 
  | 'DSM_A' 
  | 'DSM_B' 
  | 'FIBER';

export interface SnakeConnection {
  id: string;
  sourceId: string;
  sourceName: string;
  destId: string;
  destName: string;
  connector: ConnectorType;
}

// Presets

export interface Preset {
  id: string;
  name: string;
  description?: string;
  assignments: PresetAssignment[];
}

export interface PresetAssignment {
  destinationId: string;
  sourceId: string;
}

// Scaling Calculator

export interface ScalingCalculation {
  inputResolution: Resolution;
  outputResolution: Resolution;
  scaleFactor: number;
}

// App State

export interface AppState {
  currentProduction: Production | null;
  sources: Source[];
  sends: Send[];
  projectors: Projector[];
  ledScreens: LEDScreen[];
  projectionScreens: ProjectionScreen[];
  ipAddresses: IPAddress[];
  routers: Router[];
  videoSwitchers: VideoSwitcher[];
  serverAllocations: ServerAllocation[];
  checklists: ChecklistItem[];
  cableSnakes: CableSnake[];
  presets: Preset[];
}
