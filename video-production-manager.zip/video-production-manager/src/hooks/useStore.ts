import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { 
  Production, 
  Source, 
  Send, 
  LEDScreen, 
  IPAddress, 
  ChecklistItem,
  VideoSwitcher,
  ServerAllocation
} from '@/types';
import { 
  sampleProduction, 
  sampleSources, 
  sampleSends, 
  sampleLEDScreen,
  sampleIPAddresses,
  sampleChecklist,
  sampleVideoSwitcher,
  sampleServerAllocation
} from '@/data/sampleData';

interface ProductionStore {
  // Data
  production: Production | null;
  sources: Source[];
  sends: Send[];
  ledScreens: LEDScreen[];
  ipAddresses: IPAddress[];
  checklist: ChecklistItem[];
  videoSwitchers: VideoSwitcher[];
  serverAllocations: ServerAllocation[];
  
  // UI State
  activeTab: string;
  searchQuery: string;
  
  // Actions
  setProduction: (production: Production) => void;
  setActiveTab: (tab: string) => void;
  setSearchQuery: (query: string) => void;
  
  // Source Actions
  addSource: (source: Source) => void;
  updateSource: (id: string, source: Partial<Source>) => void;
  deleteSource: (id: string) => void;
  
  // Send Actions
  addSend: (send: Send) => void;
  updateSend: (id: string, send: Partial<Send>) => void;
  deleteSend: (id: string) => void;
  
  // Checklist Actions
  toggleChecklistItem: (id: string) => void;
  updateChecklistItem: (id: string, item: Partial<ChecklistItem>) => void;
  
  // IP Address Actions
  addIPAddress: (ip: IPAddress) => void;
  updateIPAddress: (ip: string, data: Partial<IPAddress>) => void;
  deleteIPAddress: (ip: string) => void;
  
  // Reset
  resetToSampleData: () => void;
}

export const useProductionStore = create<ProductionStore>()(
  persist(
    (set) => ({
      // Initial Data
      production: sampleProduction,
      sources: sampleSources,
      sends: sampleSends,
      ledScreens: [sampleLEDScreen],
      ipAddresses: sampleIPAddresses,
      checklist: sampleChecklist,
      videoSwitchers: [sampleVideoSwitcher],
      serverAllocations: [sampleServerAllocation],
      
      // UI State
      activeTab: 'dashboard',
      searchQuery: '',
      
      // Actions
      setProduction: (production) => set({ production }),
      setActiveTab: (tab) => set({ activeTab: tab }),
      setSearchQuery: (query) => set({ searchQuery: query }),
      
      // Source Actions
      addSource: (source) => set((state) => ({ 
        sources: [...state.sources, source] 
      })),
      updateSource: (id, updates) => set((state) => ({
        sources: state.sources.map(s => 
          s.id === id ? { ...s, ...updates } : s
        )
      })),
      deleteSource: (id) => set((state) => ({
        sources: state.sources.filter(s => s.id !== id)
      })),
      
      // Send Actions
      addSend: (send) => set((state) => ({ 
        sends: [...state.sends, send] 
      })),
      updateSend: (id, updates) => set((state) => ({
        sends: state.sends.map(s => 
          s.id === id ? { ...s, ...updates } : s
        )
      })),
      deleteSend: (id) => set((state) => ({
        sends: state.sends.filter(s => s.id !== id)
      })),
      
      // Checklist Actions
      toggleChecklistItem: (id) => set((state) => ({
        checklist: state.checklist.map(item =>
          item.id === id ? { ...item, completed: !item.completed } : item
        )
      })),
      updateChecklistItem: (id, updates) => set((state) => ({
        checklist: state.checklist.map(item =>
          item.id === id ? { ...item, ...updates } : item
        )
      })),
      
      // IP Address Actions
      addIPAddress: (ip) => set((state) => ({
        ipAddresses: [...state.ipAddresses, ip]
      })),
      updateIPAddress: (ip, updates) => set((state) => ({
        ipAddresses: state.ipAddresses.map(addr =>
          addr.ip === ip ? { ...addr, ...updates } : addr
        )
      })),
      deleteIPAddress: (ip) => set((state) => ({
        ipAddresses: state.ipAddresses.filter(addr => addr.ip !== ip)
      })),
      
      // Reset
      resetToSampleData: () => set({
        production: sampleProduction,
        sources: sampleSources,
        sends: sampleSends,
        ledScreens: [sampleLEDScreen],
        ipAddresses: sampleIPAddresses,
        checklist: sampleChecklist,
        videoSwitchers: [sampleVideoSwitcher],
        serverAllocations: [sampleServerAllocation],
      }),
    }),
    {
      name: 'video-production-storage',
    }
  )
);

// Selectors
export const useSourcesByType = (type: string) => 
  useProductionStore((state) => 
    state.sources.filter(s => s.type === type)
  );

export const useSendsByType = (type: string) =>
  useProductionStore((state) =>
    state.sends.filter(s => s.type === type)
  );

export const useChecklistByCategory = (category: string) =>
  useProductionStore((state) =>
    state.checklist.filter(item => item.category === category)
  );

export const useIPsByCategory = (category: string) =>
  useProductionStore((state) =>
    state.ipAddresses.filter(ip => ip.category === category)
  );

export const useChecklistProgress = () =>
  useProductionStore((state) => {
    const total = state.checklist.length;
    const completed = state.checklist.filter(item => item.completed).length;
    return { total, completed, percentage: total > 0 ? (completed / total) * 100 : 0 };
  });
