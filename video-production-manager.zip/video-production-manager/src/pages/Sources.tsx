import React from 'react';
import { Plus, Search, Filter, Edit2, Trash2 } from 'lucide-react';
import { 
  Card, 
  Button, 
  Input, 
  Badge, 
  ConnectorBadge,
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
  EmptyState
} from '@/components/ui';
import { useProductionStore } from '@/hooks/useStore';
import { cn, formatResolution, getSourceTypeIcon } from '@/utils/helpers';
import type { Source } from '@/types';

export const Sources: React.FC = () => {
  const { sources, searchQuery, setSearchQuery } = useProductionStore();
  const [selectedType, setSelectedType] = React.useState<string>('all');

  const sourceTypes = React.useMemo(() => {
    const types = new Set(sources.map(s => s.type));
    return ['all', ...Array.from(types)];
  }, [sources]);

  const filteredSources = React.useMemo(() => {
    return sources.filter(source => {
      const matchesSearch = searchQuery === '' || 
        source.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        source.id.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = selectedType === 'all' || source.type === selectedType;
      return matchesSearch && matchesType;
    });
  }, [sources, searchQuery, selectedType]);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-display font-bold text-av-text">Sources</h2>
          <p className="text-sm text-av-text-muted">
            Manage video inputs and source devices
          </p>
        </div>
        <Button variant="primary">
          <Plus className="w-4 h-4 mr-2" />
          Add Source
        </Button>
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-av-text-muted" />
              <input
                type="text"
                placeholder="Search sources..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-field w-full pl-10"
              />
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            {sourceTypes.map(type => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={cn(
                  'px-3 py-1.5 rounded-md text-sm font-medium transition-colors',
                  selectedType === type
                    ? 'bg-av-accent/20 text-av-accent border border-av-accent/30'
                    : 'bg-av-surface-light text-av-text-muted hover:text-av-text'
                )}
              >
                {type === 'all' ? 'All Types' : type}
              </button>
            ))}
          </div>
        </div>
      </Card>

      {/* Sources Table */}
      <Card className="overflow-hidden">
        {filteredSources.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Resolution</TableHead>
                <TableHead>Rate</TableHead>
                <TableHead>Output</TableHead>
                <TableHead>Notes</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSources.map((source, index) => (
                <TableRow 
                  key={source.id}
                  className="animate-slide-up"
                  style={{ animationDelay: `${index * 30}ms` }}
                >
                  <TableCell>
                    <span className="font-mono text-av-accent">{source.id}</span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span>{getSourceTypeIcon(source.type)}</span>
                      <span className="text-sm text-av-text-muted">{source.type}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="font-medium text-av-text">{source.name}</span>
                  </TableCell>
                  <TableCell>
                    <span className="font-mono text-sm">
                      {formatResolution(source.hRes, source.vRes)}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="font-mono text-sm">{source.rate}fps</span>
                  </TableCell>
                  <TableCell>
                    <ConnectorBadge connector={source.output} />
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-av-text-muted truncate max-w-[200px] block">
                      {source.note || source.secondaryDevice || '—'}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="p-1.5 rounded hover:bg-av-surface-light text-av-text-muted hover:text-av-text transition-colors">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 rounded hover:bg-av-danger/20 text-av-text-muted hover:text-av-danger transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <EmptyState
            icon={<Search className="w-8 h-8" />}
            title="No sources found"
            description="Try adjusting your search or filters"
          />
        )}
      </Card>

      {/* Summary */}
      <div className="flex flex-wrap gap-4">
        <Card className="p-4 flex-1 min-w-[200px]">
          <p className="text-sm text-av-text-muted mb-1">Total Sources</p>
          <p className="text-2xl font-mono font-bold text-av-text">{sources.length}</p>
        </Card>
        <Card className="p-4 flex-1 min-w-[200px]">
          <p className="text-sm text-av-text-muted mb-1">Cameras</p>
          <p className="text-2xl font-mono font-bold text-av-accent">
            {sources.filter(s => s.type === 'CAM' || s.type === 'PTZ' || s.type === 'ROBO').length}
          </p>
        </Card>
        <Card className="p-4 flex-1 min-w-[200px]">
          <p className="text-sm text-av-text-muted mb-1">Laptops</p>
          <p className="text-2xl font-mono font-bold text-av-info">
            {sources.filter(s => s.type === 'LAPTOP').length}
          </p>
        </Card>
        <Card className="p-4 flex-1 min-w-[200px]">
          <p className="text-sm text-av-text-muted mb-1">HDMI Sources</p>
          <p className="text-2xl font-mono font-bold text-signal-hdmi">
            {sources.filter(s => s.output === 'HDMI').length}
          </p>
        </Card>
      </div>
    </div>
  );
};
